import React, {Component} from 'react';
import Header from "./Header";

class UserPosts extends Component{
    render(){
        return(
            <div>
                <Header />
            </div>
        )
    }
}
export default UserPosts;
